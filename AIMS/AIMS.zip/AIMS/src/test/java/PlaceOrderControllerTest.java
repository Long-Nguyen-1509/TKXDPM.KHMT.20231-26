import com.example.Controller.PlaceOrderController;
import com.example.DTO.DeliveryForm;
import com.example.Entity.DeliveryInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PlaceOrderControllerTest {
    private PlaceOrderController placeOrderController;

    @BeforeEach
    public void setUp(){placeOrderController = new PlaceOrderController();}

    @Test
    public void testValidateDeliveryInfo_ValidInfo() {
        DeliveryForm deliveryForm = new DeliveryForm();
        deliveryForm.setPhone("1234567890");
        deliveryForm.setEmail("test@example.com");
        DeliveryInfo deliveryInfo = new DeliveryInfo();

        String result = placeOrderController.validateDeliveryInfo(deliveryForm);

        assertEquals("Success", result);
    }

    @Test
    public void testValidateDeliveryInfo_InvalidPhoneNumber() {
        DeliveryForm deliveryForm = new DeliveryForm();
        deliveryForm.setPhone("invalid");
        deliveryForm.setEmail("test@example.com");
        DeliveryInfo deliveryInfo = new DeliveryInfo();

        String result = placeOrderController.validateDeliveryInfo(deliveryForm);

        assertEquals("Invalid phone number", result);
    }

    @Test
    public void testValidateDeliveryInfo_InvalidPhoneNumberLength() {
        DeliveryForm deliveryForm = new DeliveryForm();
        deliveryForm.setPhone("123");
        deliveryForm.setEmail("test@example.com");
        DeliveryInfo deliveryInfo = new DeliveryInfo();

        String result = placeOrderController.validateDeliveryInfo(deliveryForm);

        assertEquals("Phone number must be between 10 or 11 digits", result);
    }

    @Test
    public void testValidateDeliveryInfo_InvalidEmail() {
        DeliveryForm deliveryForm = new DeliveryForm();
        deliveryForm.setPhone("1234567890");
        deliveryForm.setEmail("invalid-email");
        DeliveryInfo deliveryInfo = new DeliveryInfo();

        String result = placeOrderController.validateDeliveryInfo(deliveryForm);

        assertEquals("Invalid email", result);
    }
}
