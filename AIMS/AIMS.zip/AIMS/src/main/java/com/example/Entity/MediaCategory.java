package com.example.Entity;

public enum MediaCategory {
    BOOK,
    CD,
    DVD,
}
